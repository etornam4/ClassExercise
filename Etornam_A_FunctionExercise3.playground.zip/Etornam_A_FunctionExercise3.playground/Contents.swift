import UIKit
 var str = "Features of my car"

class carParts {
    var seats: Int
    var engine: String
    var color: String
    var brand: String

    init(seats: Int, engine: String, color: String, brand: String) {
        self.seats = seats
        self.engine = engine
        self.color = color
        self.brand = brand
     }
   
    func car() {
        print("These are the parts of my car!")
    }
}
var myCar = carParts(seats: 4, engine: "electric", color: "Metalic black", brand: "Audi")
myCar.seats
myCar.engine
myCar.color
myCar.brand
myCar.car()
